import pandas as pd

from mlb_data import normalize_stats_payload


def test_normalize_stats_payload_extracts_ops_and_identity():
    payload = {
        "stats": [
            {
                "splits": [
                    {
                        "season": "2025",
                        "player": {"id": 1, "fullName": "Example Hitter"},
                        "team": {"id": 10, "name": "Example Club"},
                        "stat": {
                            "gamesPlayed": 150,
                            "plateAppearances": 640,
                            "homeRuns": 31,
                            "strikeOuts": 120,
                            "baseOnBalls": 70,
                            "avg": ".282",
                            "obp": ".376",
                            "slg": ".520",
                            "ops": ".896",
                        },
                    }
                ]
            }
        ]
    }

    frame = normalize_stats_payload(payload, 2025)

    assert len(frame) == 1
    assert frame.loc[0, "player_name"] == "Example Hitter"
    assert frame.loc[0, "season"] == 2025
    assert frame.loc[0, "plateAppearances"] == 640
    assert frame.loc[0, "on_base_plus_slg"] == 0.896
