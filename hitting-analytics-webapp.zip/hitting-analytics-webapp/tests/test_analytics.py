import numpy as np
import pandas as pd

from analytics import prepare_model_bundle


def test_model_bundle_excludes_direct_ops_fields():
    rng = np.random.default_rng(7)
    rows = 80
    frame = pd.DataFrame(
        {
            "season": np.repeat(2025, rows),
            "player_id": np.arange(rows),
            "player_name": [f"Player {i}" for i in range(rows)],
            "team_id": rng.integers(1, 31, rows),
            "team_name": ["Club"] * rows,
            "plateAppearances": rng.integers(100, 700, rows),
            "homeRuns": rng.integers(0, 50, rows),
            "strikeOuts": rng.integers(20, 200, rows),
            "baseOnBalls": rng.integers(10, 100, rows),
            "avg": rng.uniform(0.180, 0.340, rows),
            "obp": rng.uniform(0.250, 0.450, rows),
            "slg": rng.uniform(0.300, 0.650, rows),
        }
    )
    frame["ops"] = frame["obp"] + frame["slg"]
    frame["on_base_plus_slg"] = frame["ops"]

    bundle = prepare_model_bundle(frame)

    assert "obp" not in bundle.features.columns
    assert "slg" not in bundle.features.columns
    assert "ops" not in bundle.features.columns
    assert "player_id" not in bundle.features.columns
    assert len(bundle.metrics) == 2
