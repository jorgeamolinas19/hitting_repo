# Data folder

No local dataset is required anymore. The application loads season-level MLB hitting statistics from the MLB Stats API at runtime.

This folder is retained only to document the evolution from the original CSV-based script.
