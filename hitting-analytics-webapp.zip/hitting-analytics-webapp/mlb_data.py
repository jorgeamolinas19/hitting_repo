from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

MLB_STATS_URL = "https://statsapi.mlb.com/api/v1/stats"


@dataclass(frozen=True)
class MLBDataConfig:
    start_season: int
    end_season: int
    min_plate_appearances: int = 100

    def seasons(self) -> range:
        return range(self.start_season, self.end_season + 1)


def _session() -> requests.Session:
    """Create an HTTP session with conservative retries for transient API errors."""
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=0.8,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset({"GET"}),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "HittingAnalyticsLab/1.0 (educational baseball analytics project)",
            "Accept": "application/json",
        }
    )
    session.mount("https://", adapter)
    return session


def _numeric(value: Any) -> float | int | None:
    """Convert MLB Stats API numeric strings to Python numbers without raising."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped or stripped in {".---", "---", "-"}:
            return None
        try:
            number = float(stripped)
        except ValueError:
            return None
        return int(number) if number.is_integer() and "." not in stripped else number
    return None


def normalize_stats_payload(payload: dict[str, Any], requested_season: int) -> pd.DataFrame:
    """Flatten one MLB Stats API season response into one row per hitter."""
    stats_groups = payload.get("stats") or []
    if not stats_groups:
        return pd.DataFrame()

    splits: list[dict[str, Any]] = []
    for group in stats_groups:
        splits.extend(group.get("splits") or [])

    rows: list[dict[str, Any]] = []
    for split in splits:
        stat = split.get("stat") or {}
        player = split.get("player") or split.get("person") or {}
        team = split.get("team") or {}

        row: dict[str, Any] = {
            "season": int(split.get("season") or requested_season),
            "player_id": player.get("id"),
            "player_name": player.get("fullName") or player.get("name"),
            "team_id": team.get("id"),
            "team_name": team.get("name"),
        }

        for key, value in stat.items():
            numeric = _numeric(value)
            if numeric is not None:
                row[key] = numeric

        # MLB's season hitting payload exposes OPS as `ops`. Normalize to the
        # original project's target name so the modeling layer stays stable.
        if "ops" in row:
            row["on_base_plus_slg"] = row["ops"]

        rows.append(row)

    return pd.DataFrame(rows)


def fetch_mlb_hitting_season(
    season: int,
    *,
    session: requests.Session | None = None,
    timeout: int = 30,
) -> pd.DataFrame:
    """Fetch all MLB regular-season hitter stats for one season."""
    owns_session = session is None
    http = session or _session()
    params = {
        "stats": "season",
        "group": "hitting",
        "season": season,
        "sportIds": 1,
        "gameType": "R",
        "playerPool": "ALL",
        "limit": 5000,
        "hydrate": "person,team",
    }

    try:
        response = http.get(MLB_STATS_URL, params=params, timeout=timeout)
        response.raise_for_status()
        payload = response.json()
    except requests.RequestException as exc:
        raise RuntimeError(f"MLB Stats API request failed for {season}: {exc}") from exc
    except ValueError as exc:
        raise RuntimeError(f"MLB Stats API returned invalid JSON for {season}.") from exc
    finally:
        if owns_session:
            http.close()

    dataframe = normalize_stats_payload(payload, season)
    if dataframe.empty:
        raise RuntimeError(f"MLB Stats API returned no hitter rows for {season}.")
    if "on_base_plus_slg" not in dataframe.columns:
        raise RuntimeError(
            "MLB Stats API response did not include OPS. The upstream response format may have changed."
        )
    return dataframe


def fetch_mlb_hitting_range(config: MLBDataConfig) -> pd.DataFrame:
    """Fetch, combine, and filter multiple MLB seasons."""
    if config.start_season > config.end_season:
        raise ValueError("start_season must be less than or equal to end_season")
    if config.min_plate_appearances < 0:
        raise ValueError("min_plate_appearances cannot be negative")

    http = _session()
    frames: list[pd.DataFrame] = []
    errors: list[str] = []
    try:
        for season in config.seasons():
            try:
                frames.append(fetch_mlb_hitting_season(season, session=http))
            except RuntimeError as exc:
                errors.append(str(exc))
    finally:
        http.close()

    if not frames:
        detail = " | ".join(errors) if errors else "No seasons returned data."
        raise RuntimeError(f"Unable to load MLB hitting data. {detail}")

    combined = pd.concat(frames, ignore_index=True, sort=False)

    if "plateAppearances" in combined.columns:
        combined = combined[
            pd.to_numeric(combined["plateAppearances"], errors="coerce").fillna(0)
            >= config.min_plate_appearances
        ].copy()

    combined = combined.drop_duplicates(subset=["season", "player_id"], keep="last")
    combined = combined.sort_values(["season", "player_name"], na_position="last").reset_index(drop=True)

    if combined.empty:
        raise RuntimeError(
            "The MLB API returned data, but no hitters met the selected plate-appearance threshold."
        )

    combined.attrs["source_errors"] = errors
    return combined
