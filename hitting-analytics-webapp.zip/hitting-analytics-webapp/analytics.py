from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO

import numpy as np
import pandas as pd
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

TARGET_COLUMN = "on_base_plus_slg"
IDENTITY_COLUMNS = {
    "last_name, first_name",
    "player_id",
    "player_name",
    "team_id",
    "team_name",
    "season",
}

# OPS = OBP + SLG. If these columns exist, using them to predict OPS would create
# target leakage and make model performance look artificially strong.
LEAKAGE_COLUMNS = {
    "on_base_percent",
    "on_base_percentage",
    "obp",
    "slg",
    "slg_percent",
    "slugging_percentage",
    "ops",
}


@dataclass
class ModelBundle:
    dataframe: pd.DataFrame
    features: pd.DataFrame
    target: pd.Series
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series
    linear_model: Pipeline
    random_forest_model: Pipeline
    linear_predictions: np.ndarray
    random_forest_predictions: np.ndarray
    metrics: pd.DataFrame
    rf_importance: pd.DataFrame
    lr_coefficients: pd.DataFrame
    excluded_columns: list[str]
    dropped_non_numeric: list[str]


def load_dataframe(source: str | Path | BinaryIO) -> pd.DataFrame:
    """Load a CSV from disk or a Streamlit UploadedFile-like object."""
    return pd.read_csv(source)


def _metric_row(model_name: str, actual: pd.Series, predicted: np.ndarray) -> dict[str, float | str]:
    return {
        "Model": model_name,
        "MAE": mean_absolute_error(actual, predicted),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
        "R²": r2_score(actual, predicted),
    }


def prepare_model_bundle(dataframe: pd.DataFrame, test_size: float = 0.20, random_state: int = 42) -> ModelBundle:
    if TARGET_COLUMN not in dataframe.columns:
        raise ValueError(
            f"Dataset must contain the target column '{TARGET_COLUMN}'. "
            f"Found {len(dataframe.columns)} columns instead."
        )

    df = dataframe.copy()
    target = pd.to_numeric(df[TARGET_COLUMN], errors="coerce")

    if target.isna().all():
        raise ValueError(f"Target column '{TARGET_COLUMN}' does not contain numeric values.")

    valid_target = target.notna()
    df = df.loc[valid_target].reset_index(drop=True)
    target = target.loc[valid_target].reset_index(drop=True)

    excluded_columns = [c for c in df.columns if c in IDENTITY_COLUMNS or c.lower() in LEAKAGE_COLUMNS]
    candidate_features = df.drop(columns=[TARGET_COLUMN, *excluded_columns], errors="ignore")

    numeric_features = candidate_features.select_dtypes(include=[np.number]).copy()
    dropped_non_numeric = [c for c in candidate_features.columns if c not in numeric_features.columns]
    numeric_features = numeric_features.dropna(axis=1, how="all")

    if numeric_features.empty:
        raise ValueError("No usable numeric predictor columns remain after cleaning the dataset.")

    X_train, X_test, y_train, y_test = train_test_split(
        numeric_features,
        target,
        test_size=test_size,
        random_state=random_state,
    )

    linear_model = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", LinearRegression()),
        ]
    )
    random_forest_model = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            (
                "model",
                RandomForestRegressor(
                    n_estimators=300,
                    random_state=random_state,
                    max_depth=None,
                    min_samples_leaf=2,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    linear_model.fit(X_train, y_train)
    random_forest_model.fit(X_train, y_train)

    linear_predictions = linear_model.predict(X_test)
    random_forest_predictions = random_forest_model.predict(X_test)

    metrics = pd.DataFrame(
        [
            _metric_row("Linear Regression", y_test, linear_predictions),
            _metric_row("Random Forest", y_test, random_forest_predictions),
        ]
    )

    forest = random_forest_model.named_steps["model"]
    rf_importance = (
        pd.DataFrame({"Feature": numeric_features.columns, "Importance": forest.feature_importances_})
        .sort_values("Importance", ascending=False)
        .reset_index(drop=True)
    )

    linear = linear_model.named_steps["model"]
    lr_coefficients = (
        pd.DataFrame({"Feature": numeric_features.columns, "Coefficient": linear.coef_})
        .assign(AbsCoefficient=lambda d: d["Coefficient"].abs())
        .sort_values("AbsCoefficient", ascending=False)
        .drop(columns="AbsCoefficient")
        .reset_index(drop=True)
    )

    return ModelBundle(
        dataframe=df,
        features=numeric_features,
        target=target,
        X_train=X_train,
        X_test=X_test,
        y_train=y_train,
        y_test=y_test,
        linear_model=linear_model,
        random_forest_model=random_forest_model,
        linear_predictions=linear_predictions,
        random_forest_predictions=random_forest_predictions,
        metrics=metrics,
        rf_importance=rf_importance,
        lr_coefficients=lr_coefficients,
        excluded_columns=excluded_columns,
        dropped_non_numeric=dropped_non_numeric,
    )


def default_prediction_row(bundle: ModelBundle) -> pd.DataFrame:
    """Create one median-valued input row in the exact feature order used for training."""
    values = bundle.features.median(numeric_only=True).reindex(bundle.features.columns)
    return pd.DataFrame([values], columns=bundle.features.columns)


def predict_ops(bundle: ModelBundle, values: dict[str, float]) -> tuple[float, float]:
    row = default_prediction_row(bundle)
    for feature, value in values.items():
        if feature in row.columns:
            row.loc[0, feature] = value

    linear_prediction = float(bundle.linear_model.predict(row)[0])
    forest_prediction = float(bundle.random_forest_model.predict(row)[0])
    return linear_prediction, forest_prediction
