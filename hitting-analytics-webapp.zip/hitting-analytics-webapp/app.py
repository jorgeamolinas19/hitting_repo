from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analytics import TARGET_COLUMN, predict_ops, prepare_model_bundle
from mlb_data import MLBDataConfig, fetch_mlb_hitting_range

st.set_page_config(
    page_title="Hitting Analytics Lab",
    page_icon="⚾",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    :root {
        --ink: #132018;
        --muted: #66736a;
        --panel: #f7f8f4;
        --line: #e5e9e3;
        --accent: #1f6f4a;
        --accent-soft: #eaf4ee;
    }
    .stApp { background: #fcfcfa; }
    .block-container { max-width: 1250px; padding-top: 2rem; padding-bottom: 4rem; }
    [data-testid="stSidebar"] { border-right: 1px solid var(--line); }
    .hero {
        padding: 2.1rem 2.2rem;
        border: 1px solid var(--line);
        background: linear-gradient(135deg, #ffffff 0%, #f4f7f3 100%);
        border-radius: 22px;
        margin-bottom: 1.25rem;
    }
    .eyebrow {
        color: var(--accent);
        text-transform: uppercase;
        letter-spacing: .11em;
        font-size: .76rem;
        font-weight: 750;
        margin-bottom: .55rem;
    }
    .hero h1 {
        color: var(--ink);
        font-size: clamp(2.25rem, 5vw, 4.2rem);
        line-height: .98;
        letter-spacing: -.045em;
        margin: 0 0 .85rem 0;
        max-width: 780px;
    }
    .hero p {
        color: var(--muted);
        font-size: 1.04rem;
        line-height: 1.65;
        max-width: 790px;
        margin: 0;
    }
    .section-label {
        color: var(--muted);
        font-size: .82rem;
        font-weight: 700;
        letter-spacing: .075em;
        text-transform: uppercase;
        margin: .45rem 0 .35rem 0;
    }
    .mini-note {
        background: var(--accent-soft);
        border: 1px solid #d8e8de;
        border-radius: 14px;
        padding: .85rem 1rem;
        color: #315441;
        font-size: .9rem;
    }
    div[data-testid="stMetric"] {
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 16px;
        padding: .95rem 1rem;
    }
    div[data-testid="stMetricValue"] { letter-spacing: -.03em; }
    .footer-note { color: var(--muted); font-size: .84rem; margin-top: 2rem; }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data(ttl=24 * 60 * 60, show_spinner=False)
def load_live_data(start_season: int, end_season: int, min_plate_appearances: int) -> pd.DataFrame:
    config = MLBDataConfig(
        start_season=start_season,
        end_season=end_season,
        min_plate_appearances=min_plate_appearances,
    )
    return fetch_mlb_hitting_range(config)


@st.cache_resource(show_spinner="Training models...")
def build_bundle(dataframe: pd.DataFrame):
    return prepare_model_bundle(dataframe)


def source_data(start_season: int, end_season: int, min_plate_appearances: int) -> tuple[pd.DataFrame | None, str, str | None]:
    try:
        with st.spinner("Loading MLB hitting data..."):
            dataframe = load_live_data(start_season, end_season, min_plate_appearances)
        label = f"MLB Stats API · {start_season}–{end_season} · ≥{min_plate_appearances} PA"
        source_errors = dataframe.attrs.get("source_errors") or []
        warning = None
        if source_errors:
            warning = "Some selected seasons could not be refreshed: " + " | ".join(source_errors)
        return dataframe, label, warning
    except Exception as exc:
        return None, "MLB Stats API unavailable", str(exc)

def ideal_line(actual: pd.Series, predicted: np.ndarray) -> tuple[float, float]:
    low = float(min(actual.min(), np.min(predicted)))
    high = float(max(actual.max(), np.max(predicted)))
    return low, high


def actual_vs_predicted(actual: pd.Series, predicted: np.ndarray, title: str) -> go.Figure:
    frame = pd.DataFrame({"Actual OPS": actual.to_numpy(), "Predicted OPS": predicted})
    fig = px.scatter(frame, x="Actual OPS", y="Predicted OPS", opacity=0.7)
    low, high = ideal_line(actual, predicted)
    fig.add_trace(
        go.Scatter(
            x=[low, high],
            y=[low, high],
            mode="lines",
            name="Perfect prediction",
            line=dict(dash="dash", width=2),
        )
    )
    fig.update_layout(title=title, height=430, legend_title_text="", margin=dict(l=20, r=20, t=55, b=20))
    return fig


def residual_plot(actual: pd.Series, predicted: np.ndarray, title: str) -> go.Figure:
    residual = actual.to_numpy() - predicted
    frame = pd.DataFrame({"Predicted OPS": predicted, "Residual": residual})
    fig = px.scatter(frame, x="Predicted OPS", y="Residual", opacity=0.7)
    fig.add_hline(y=0, line_dash="dash")
    fig.update_layout(title=title, height=410, margin=dict(l=20, r=20, t=55, b=20))
    return fig


def feature_bar(frame: pd.DataFrame, value_column: str, title: str, top_n: int = 12) -> go.Figure:
    plot_df = frame.head(top_n).iloc[::-1]
    fig = px.bar(plot_df, x=value_column, y="Feature", orientation="h")
    fig.update_layout(title=title, height=max(430, top_n * 32), margin=dict(l=20, r=20, t=55, b=20))
    return fig


def format_metric(value: float, kind: str) -> str:
    if kind == "R²":
        return f"{value:.3f}"
    return f"{value:.4f}"


def overview(bundle):
    st.markdown(
        """
        <div class="hero">
          <div class="eyebrow">Machine learning • baseball analytics</div>
          <h1>Understand what drives a hitter's OPS.</h1>
          <p>
            Explore live MLB season data, compare linear regression with a 300-tree random forest, inspect the strongest hitting signals,
            and experiment with player profiles to generate OPS estimates.
          </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    best_idx = bundle.metrics["RMSE"].idxmin()
    best = bundle.metrics.loc[best_idx]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Rows analyzed", f"{len(bundle.dataframe):,}")
    c2.metric("Predictor features", f"{bundle.features.shape[1]:,}")
    c3.metric("Best holdout R²", f"{bundle.metrics['R²'].max():.3f}")
    c4.metric("Lowest RMSE", f"{best['RMSE']:.4f}", help=str(best["Model"]))

    st.markdown("<div class='section-label'>Model leaderboard</div>", unsafe_allow_html=True)
    table = bundle.metrics.copy().sort_values("RMSE")
    st.dataframe(
        table.style.format({"MAE": "{:.4f}", "RMSE": "{:.4f}", "R²": "{:.3f}"}),
        use_container_width=True,
        hide_index=True,
    )

    left, right = st.columns(2)
    with left:
        st.plotly_chart(
            actual_vs_predicted(bundle.y_test, bundle.linear_predictions, "Linear Regression · Actual vs Predicted"),
            use_container_width=True,
        )
    with right:
        st.plotly_chart(
            actual_vs_predicted(bundle.y_test, bundle.random_forest_predictions, "Random Forest · Actual vs Predicted"),
            use_container_width=True,
        )

    st.markdown(
        "<div class='mini-note'><strong>Live data + leakage protection.</strong> The app pulls MLB regular-season hitting data from the MLB Stats API and automatically removes player/team identifiers plus OBP/SLG/OPS fields before training.</div>",
        unsafe_allow_html=True,
    )


def predictor(bundle):
    st.header("OPS Predictor")
    st.caption("Build a hitter profile using the most influential model features. Features you do not change remain at the dataset median.")

    top_features = bundle.rf_importance["Feature"].head(min(10, len(bundle.rf_importance))).tolist()
    values: dict[str, float] = {}

    st.markdown("<div class='section-label'>Hitter profile</div>", unsafe_allow_html=True)
    cols = st.columns(2)
    for idx, feature in enumerate(top_features):
        series = bundle.features[feature].dropna()
        if series.empty:
            continue
        minimum = float(series.quantile(0.01))
        maximum = float(series.quantile(0.99))
        median = float(series.median())
        if minimum == maximum:
            values[feature] = median
            continue

        with cols[idx % 2]:
            values[feature] = st.slider(
                feature,
                min_value=minimum,
                max_value=maximum,
                value=float(np.clip(median, minimum, maximum)),
                help=f"Observed median: {median:.3f}",
            )

    linear_prediction, forest_prediction = predict_ops(bundle, values)
    model_choice = st.segmented_control(
        "Primary model",
        options=["Random Forest", "Linear Regression"],
        default="Random Forest",
    )
    primary = forest_prediction if model_choice == "Random Forest" else linear_prediction

    target = bundle.target
    percentile = float((target <= primary).mean() * 100)
    observed_min, observed_max = float(target.min()), float(target.max())

    st.markdown("<div class='section-label'>Prediction</div>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    c1.metric("Predicted OPS", f"{primary:.3f}")
    c2.metric("Dataset percentile", f"{percentile:.0f}th")
    c3.metric("Observed OPS range", f"{observed_min:.3f}–{observed_max:.3f}")

    compare = pd.DataFrame(
        {
            "Model": ["Linear Regression", "Random Forest"],
            "Predicted OPS": [linear_prediction, forest_prediction],
        }
    )
    fig = px.bar(compare, x="Model", y="Predicted OPS", text_auto=".3f")
    fig.update_layout(height=360, title="Model prediction comparison", margin=dict(l=20, r=20, t=55, b=20))
    st.plotly_chart(fig, use_container_width=True)

    if primary < observed_min or primary > observed_max:
        st.warning("This prediction falls outside the OPS range observed in the training dataset. Treat it as an extrapolation, not a validated estimate.")


def feature_explorer(bundle):
    st.header("Feature Explorer")
    st.caption("See what each model learned and then inspect individual relationships with OPS.")

    left, right = st.columns(2)
    with left:
        st.plotly_chart(
            feature_bar(bundle.rf_importance, "Importance", "Random Forest · Feature Importance"),
            use_container_width=True,
        )
    with right:
        st.plotly_chart(
            feature_bar(bundle.lr_coefficients, "Coefficient", "Linear Regression · Standardized Coefficients"),
            use_container_width=True,
        )

    st.markdown("<div class='section-label'>Inspect a feature</div>", unsafe_allow_html=True)
    feature = st.selectbox("Feature", options=bundle.rf_importance["Feature"].tolist())
    plot_df = pd.DataFrame({feature: bundle.features[feature], "OPS": bundle.target}).dropna()
    fig = px.scatter(plot_df, x=feature, y="OPS", trendline="ols", opacity=0.55)
    fig.update_layout(height=460, title=f"{feature} vs OPS", margin=dict(l=20, r=20, t=55, b=20))
    st.plotly_chart(fig, use_container_width=True)

    st.info("Feature importance and regression coefficients describe model behavior, not causal effects. Correlated baseball metrics can share or distort apparent importance.")


def diagnostics(bundle):
    st.header("Model Diagnostics")
    st.caption("Evaluate error patterns instead of judging the models from a single score.")

    c1, c2 = st.columns(2)
    with c1:
        st.plotly_chart(
            residual_plot(bundle.y_test, bundle.linear_predictions, "Linear Regression · Residuals"),
            use_container_width=True,
        )
    with c2:
        st.plotly_chart(
            residual_plot(bundle.y_test, bundle.random_forest_predictions, "Random Forest · Residuals"),
            use_container_width=True,
        )

    st.markdown("<div class='section-label'>Error metrics</div>", unsafe_allow_html=True)
    st.dataframe(
        bundle.metrics.style.format({"MAE": "{:.4f}", "RMSE": "{:.4f}", "R²": "{:.3f}"}),
        use_container_width=True,
        hide_index=True,
    )

    with st.expander("Data quality and exclusions"):
        st.write(f"Training rows: **{len(bundle.X_train):,}**")
        st.write(f"Holdout rows: **{len(bundle.X_test):,}**")
        st.write(f"Numeric features used: **{bundle.features.shape[1]:,}**")
        st.write("Excluded leakage/identity columns:", bundle.excluded_columns or "None found")
        st.write("Dropped non-numeric columns:", bundle.dropped_non_numeric or "None")
        missing = int(bundle.features.isna().sum().sum())
        st.write(f"Missing predictor cells handled with median imputation: **{missing:,}**")


def methodology(bundle):
    st.header("About the Project")
    st.markdown(
        """
        This app evolves an exploratory Python baseball analytics script into a public-facing ML product backed by the MLB Stats API.

        **Modeling workflow**
        - Data source: MLB Stats API, regular-season season-level hitting statistics
        - Target: OPS (normalized internally as `on_base_plus_slg`)
        - Holdout split: 80% training / 20% testing with a reproducible random seed
        - Linear model: median imputation → standardization → ordinary least-squares regression
        - Nonlinear model: median imputation → 300-tree random forest
        - Evaluation: MAE, RMSE, and R² on the untouched holdout set
        - Interpretation: random-forest feature importance and standardized linear-regression coefficients

        **Why the pipeline changed from the original script**
        - Standard deviation after standardization is approximately **1**, not 0.
        - Scaling is retained for coefficient comparability, not because ordinary OLS inherently needs scaled inputs.
        - Player/team identifiers and common OBP/SLG/OPS fields are excluded to reduce direct target leakage.
        - Missing predictor values are handled explicitly with median imputation.

        **Important limitation**
        This is an analytical/educational model. A random train/test split measures how well the model generalizes to held-out player-seasons from the selected historical data. It does **not** by itself prove that the app can forecast a player's future season. Current-season data is year-to-date when selected.
        """
    )

    with st.expander("Current feature list"):
        st.dataframe(pd.DataFrame({"Feature": bundle.features.columns}), use_container_width=True, hide_index=True)


st.sidebar.markdown("## ⚾ Hitting Analytics")
st.sidebar.caption("Interactive MLB hitting model")
page = st.sidebar.radio(
    "Explore",
    ["Overview", "OPS Predictor", "Feature Explorer", "Diagnostics", "Methodology"],
    label_visibility="collapsed",
)

st.sidebar.divider()
st.sidebar.markdown("### Data")
current_year = datetime.now().year
available_years = list(range(2015, current_year + 1))
default_end = current_year - 1
default_start = max(2015, default_end - 4)
start_season = st.sidebar.selectbox(
    "Start season",
    available_years,
    index=available_years.index(default_start),
)
end_candidates = [year for year in available_years if year >= start_season]
end_season = st.sidebar.selectbox(
    "End season",
    end_candidates,
    index=end_candidates.index(default_end) if default_end in end_candidates else len(end_candidates) - 1,
)
min_plate_appearances = st.sidebar.slider(
    "Minimum plate appearances",
    min_value=25,
    max_value=400,
    value=100,
    step=25,
    help="Filters out very small season samples before model training.",
)

if st.sidebar.button("Refresh from MLB", use_container_width=True):
    load_live_data.clear()
    st.rerun()

dataframe, data_label, data_warning = source_data(start_season, end_season, min_plate_appearances)
st.sidebar.caption(data_label)
if end_season == current_year:
    st.sidebar.caption(f"{current_year} data is year-to-date.")

if dataframe is None:
    st.markdown(
        """
        <div class="hero">
          <div class="eyebrow">Live data connection</div>
          <h1>The MLB data source could not be reached.</h1>
          <p>
            This app normally loads regular-season hitting statistics directly from the MLB Stats API.
            Try the refresh button in the sidebar; no CSV upload is required.
          </p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    if data_warning:
        st.error(data_warning)
    st.stop()

if data_warning:
    st.warning(data_warning)

try:
    bundle = build_bundle(dataframe)
except Exception as exc:
    st.error("The MLB data could not be prepared for modeling.")
    st.exception(exc)
    st.stop()

if page == "Overview":
    overview(bundle)
elif page == "OPS Predictor":
    predictor(bundle)
elif page == "Feature Explorer":
    feature_explorer(bundle)
elif page == "Diagnostics":
    diagnostics(bundle)
else:
    methodology(bundle)

st.markdown(
    "<div class='footer-note'>Data: MLB Stats API · Built with Python, scikit-learn, Plotly, and Streamlit.</div>",
    unsafe_allow_html=True,
)
