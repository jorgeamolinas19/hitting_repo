# ⚾ Hitting Analytics Lab

A public machine-learning web app that pulls MLB hitting data automatically, compares regression models for OPS estimation, and lets visitors explore model behavior interactively.

## Live data source

No CSV is required.

The app requests regular-season, season-level MLB hitting statistics from the public MLB Stats API:

```text
https://statsapi.mlb.com/api/v1/stats
```

The app queries one season at a time, combines the results, filters by a visitor-selected minimum plate-appearance threshold, and caches the result for 24 hours.

Default view:

- Last five completed MLB seasons
- Minimum 100 plate appearances per player-season
- Current season available as a year-to-date option

## Product features

- Live MLB data ingestion
- Adjustable historical season range
- Adjustable minimum plate-appearance threshold
- Linear Regression vs 300-tree Random Forest
- MAE, RMSE, and R² comparison
- Actual-vs-predicted charts
- Residual diagnostics
- Interactive OPS estimator
- Random Forest feature importance
- Standardized Linear Regression coefficients
- Explicit missing-value handling
- Automatic removal of player/team identifiers and direct OBP/SLG/OPS leakage fields
- 24-hour API caching and retry handling
- One-click manual data refresh

The original exploratory script is preserved under `legacy/HittingAnalytics.py`.

## Run locally

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

macOS/Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

An internet connection is required when a season is not already cached because the application retrieves its data from the MLB Stats API.

## Publish for anyone to use

1. Create a GitHub repository, for example `hitting-analytics-lab`.
2. Push the contents of this folder to the repository.
3. Sign in to Streamlit Community Cloud with GitHub.
4. Create a new app from the repository.
5. Select `app.py` as the entrypoint.
6. Choose the public `*.streamlit.app` subdomain and deploy.

No dataset needs to be uploaded to GitHub. Every visitor uses the server-side MLB data connection.

## Architecture

```text
Visitor browser
      │
      ▼
Streamlit web app
      │
      ├──► MLB Stats API ──► season-level hitter data
      │        │
      │        └── cached for 24 hours
      │
      ├──► preprocessing / leakage protection
      │
      ├──► Linear Regression
      │
      └──► Random Forest
               │
               ▼
      predictions + diagnostics + feature analysis
```

## Suggested resume description

**Hitting Analytics Lab — Python, scikit-learn, Streamlit, Plotly, REST APIs**  
Built and deployed an interactive MLB analytics application that ingests live season-level hitting data from the MLB Stats API, trains and compares linear and ensemble regression models for OPS estimation, and surfaces model diagnostics, feature importance, and interactive hitter simulations through a public web interface.

## Modeling note

This is an analytical/educational model. Its random holdout evaluation measures performance on unseen player-season rows from the selected data, not true future-season forecasting. Direct OBP, SLG, and OPS fields are removed from model inputs because OPS is defined from OBP and SLG.
