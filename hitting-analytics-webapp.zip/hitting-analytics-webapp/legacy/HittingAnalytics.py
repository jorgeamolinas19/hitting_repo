import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

def eval_model(Name, Y_actual, Y_predict):
    MAE = mean_absolute_error(Y_actual, Y_predict)
    RMSE = np.sqrt(mean_squared_error(Y_actual, Y_predict))
    RSquared = r2_score(Y_actual, Y_predict)

    return MAE, RMSE, RSquared

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
               DATAFRAME/TRAINING/TESTING SETS SET-UP
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
OUTCOME_COLUMN = "on_base_plus_slg"
dataframe = pd.read_csv("Data\\baseball_stats.csv")

'''
# Check if dataframe has any null/empty values, commented out after initial check
print(dataframe.isna().sum())

# Get column info for use in data analysis, commented out after initial check
print(dataframe.info())
'''

dataframe = dataframe.drop(columns=["last_name, first_name", "player_id"]) # Remove irrelevant columns

Features = dataframe.drop(columns=[OUTCOME_COLUMN]) # Drops target column for models to use predictor features more effectively, stored in new frame
Target = dataframe[OUTCOME_COLUMN]  # Creates frame with target column only for checking predictions

# Perform splitting of data for training and testing using sklearn
X_train, X_test, Y_train, Y_test = train_test_split(Features, Target, test_size=0.2, random_state=42)



"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
                                            MODEL SET-UP AND TRAINING/PREDICTIONS
    Scale predictor features for more accuracte use and preventing one feature from dominating another
        - Dataframe as a whole is not scaled because of later models being used to analyze data (random foresting)
        - Scales features based on standardization (z = [x − μ] / σ​)
            - Mean (μ) of each feature is 0
            - Standard deviation (σ) of each feature is 0
        - After fitting for training data, apply same fit to train set (hence why transform and not fit_transform is used)
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
scaler = StandardScaler()

# Scale training set along with test set accordingly
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create linear model and train on training set and corresponding training outcomes
LINEAR_MODEL = LinearRegression()
LINEAR_MODEL.fit(X_train_scaled, Y_train)

# Test trained model on test data
LR_predictions = LINEAR_MODEL.predict(X_test_scaled)


# Create randome foresting model for obtaining average of redictions based on number of trees (set to 300)
RANDOM_FOREST_MODEL = RandomForestRegressor(n_estimators=300, random_state=42, max_depth=None, min_samples_leaf=2)

# Fit model on training data with OPS training data actual values
RANDOM_FOREST_MODEL.fit(X_train, Y_train)

# Predict based on test data with trained model
RF_predictions = RANDOM_FOREST_MODEL.predict(X_test)



"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
  DISPLAY GRAPHS FOR LINEAR REGRESSION AND RANDOM FOREST MODELS AS VISUALS
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
plt.figure(figsize=(8,6))
plt.scatter(Y_test, LR_predictions, alpha=0.7)
plt.xlabel("Actual OPS")
plt.ylabel("Predicted OPS")
plt.title("Linear Regression: Actual vs Predicted OPS")
plt.plot([Target.min(), Target.max()], [Target.min(), Target.max()])
plt.show()


plt.figure(figsize=(8,6))
plt.scatter(Y_test, RF_predictions, alpha=0.7)
plt.xlabel("Actual OPS")
plt.ylabel("Predicted OPS")
plt.title("Random Forest: Actual vs Predicted OPS")
plt.plot([Target.min(), Target.max()], [Target.min(), Target.max()])
plt.show()



"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
 CALCULATE MEAN ABSOLUTE ERRORS, ROOT MEAN SQUARED ERRORS, AND R^2 SCORES
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
LR_metrics = eval_model("Linear Regression", Y_test, LR_predictions)
RF_metrics = eval_model("Random Forest Regression", Y_test, RF_predictions)

ResultMetrics = pd.DataFrame({
    "Model": ["Linear Regression", "Random Forest"],
    "MAE": [LR_metrics[0], RF_metrics[0]],
    "RMSE": [LR_metrics[1], RF_metrics[1]],
    "R2": [LR_metrics[2], RF_metrics[2]]
})
print("Mean Absolute Error - Root Mean Squared Error - R^2 Scores")
print(ResultMetrics)


"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
   DISPLAY RESIDUALS, RANDOM FOREST FEATURE IMPORTANCE, AND LINEAR REGRESSION COEFFICIENTS
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
LR_residuals = Y_test - LR_predictions  # Calculate how far off prediction was
RF_residuals = Y_test - RF_predictions  # Calculate how far off prediction was

plt.figure(figsize=(8,6))
plt.scatter(LR_predictions, LR_residuals, alpha=0.7)
plt.axhline(y=0)    # Perfect prediction line (no error)
plt.xlabel("Predicted OPS")
plt.ylabel("Residuals")
plt.title("Linear Regression Residual Plot")
plt.show()

plt.figure(figsize=(8,6))
plt.scatter(RF_predictions, RF_residuals, alpha=0.7)
plt.axhline(y=0)
plt.xlabel("Predicted OPS")
plt.ylabel("Residuals")
plt.title("Random Forest Residual Plot")
plt.show()


ImportantFeatures = pd.DataFrame({"Feature": Features.columns, "Importance": RANDOM_FOREST_MODEL.feature_importances_}).sort_values(by="Importance", ascending=False)

print("\n\n\nRandom Forest Feature Importance")
print(ImportantFeatures)

# Create bar graph to illustrate top 10 important features
plt.figure(figsize=(10,6))
plt.barh(
    ImportantFeatures["Feature"][:10],
    ImportantFeatures["Importance"][:10]
)
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.title("Top 10 Feature Importance - Random Forest")
plt.gca().invert_yaxis()
plt.show()

LRCoefficients = pd.DataFrame({"Feature": Features.columns, "Coefficient": LINEAR_MODEL.coef_}).sort_values(by="Coefficient", key=abs, ascending=False)

print("\nLinear Regression Coefficients")
print(LRCoefficients)

# Create bar graph to illustrate value/impact of coefficients
plt.figure(figsize=(10,6))
plt.barh(
    LRCoefficients["Feature"][:10],
    LRCoefficients["Coefficient"][:10]
)
plt.xlabel("Coefficient Value")
plt.ylabel("Feature")
plt.title("Top 10 Linear Regression Coefficients")
plt.gca().invert_yaxis()
plt.show()











               
