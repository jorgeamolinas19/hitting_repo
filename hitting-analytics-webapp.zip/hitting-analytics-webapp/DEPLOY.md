# Deploy in 4 steps

1. Push this project to a GitHub repository.
2. Sign in to Streamlit Community Cloud with GitHub.
3. Create an app from the repository and choose `app.py` as the entrypoint.
4. Pick your public `*.streamlit.app` URL and deploy.

There is no CSV to upload. The deployed server requests MLB hitting data from the MLB Stats API and caches responses for 24 hours.

## Deployment requirement

The hosting environment must allow outbound HTTPS requests to:

```text
https://statsapi.mlb.com
```

Streamlit Community Cloud applications normally have outbound internet access, so no API key or secret is needed for this data connection.
